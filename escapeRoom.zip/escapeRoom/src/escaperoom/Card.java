
package escaperoom;

/**
 *
 * @author Connor McCloskey
 */
/**
 * The <code>Card</code> class represents a single playing card
 * of a rank and suite.
 * @author Connor McCloskey
 */
public class Card implements Comparable<Card>{
   /**
    * The <code>fileExtension</code> will be the shared file extension for all images.
    */
    private static String fileExtension;
    /**
     * The <code>imageFile</code> field will be a String representing the file name
     * that corresponds to the card.
     */
    private String imageFile;

    //Fields "Card has a data"
    /**
     * The <code>rank</code> field will be an integer value 2 to 10
     * 11 is Jack, 12 is Queen, 13 is King, 14 is an Ace.
     */
    private int rank;
    /**
     * The <code>suit</code> field will be an integer value with the following
     * designations:
     * 1 - Clubs
     * 2- Diamonds
     * 3 - Hearts
     * 4 - Spades
     */
    private int suit;
    
    //Constructors
    /**
     * Default constructor of the Card class - creates a card of 2, 1
     * (Two of clubs)
     */
    public Card(){
        this(2,1);
    }//end default constructor
    /**
     * Other constructor that takes rank and suit as the argument
     * @param rankIn as int that must be 2 - 14
     * @param suitIn as int that must be 1 -4
     */
    public Card(int rankIn, int suitIn){
        setRank(rankIn);
        setSuit(suitIn);
        Card.fileExtension = ".png";
    }//end constructor
    
    //Getters
    /**
     * This method returns the field representing the rank as an int
     * @return int
     */
    public int getRank(){return this.rank;}
    
    /**
     * The method returns the field representing the suit as an int
     * @return int
     */
    public int getSuit(){return this.suit;}
    
    public String getImageFile(){
        char chRank, chSuit;
        if(rank == 14)
            chRank = 'A';
        else if (rank == 13)
            chRank = 'K';
        //to do - finish 12, 11, 10
        else if (rank == 12)
            chRank = 'Q';
        else if (rank == 11)
            chRank = 'J';
        else if (rank == 10)
            chRank = 'T';
        else 
            chRank = Integer.toString(rank).charAt(0);
        
        if (suit == 1)
            chSuit = 'C';
        else if (suit == 2)
            chSuit = 'D';
        else if (suit == 3)
            chSuit = 'H';
        else
            chSuit = 'S';
        imageFile = "/escaperoom/images/" + Character.toString(chRank) + Character.toString(chSuit) + Card.fileExtension;
        return imageFile;
    }
    
    
    //Setters
    /**
     * The method takes an int value 2-14 to set the field <code>rank</code>.
     * @param rankIn as int
     */
    public void setRank(int rankIn){
        if (rankIn >= 2 && rankIn <= 14)
            this.rank = rankIn;
    }//end setRank
    /**
     * This method takes an int value between 1 and 4 sot set the field <code>suit</code>
     * @param suitIn  as int
     */
    public void setSuit(int suitIn){
        if (suitIn >= 1 && suitIn <= 4)
            this.suit = suitIn;
    }//end setSuit
    
    //Other

    /**
     * The compareTo method compares 2 <code>Card</code> objects and returns
     * 0 if they are equal, 1 if the first is greater than the second, or -1
     * if the first is less than the second
     * @param card2
     * @return int 
     * @see Comparable
     */
    @Override
    public int compareTo(Card card2) {
        if (this.rank > card2.rank)
            return 1;
        else if (this.rank < card2.rank)
            return -1;
        return 0;
    }
    
    /**
     * The toString is overridden to take a Card object and determine the long notation
     * of the card; therefore Card(2,1) will return "two of clubs."
     * @return 
     */
    @Override
    public String toString(){
        String card;
        if (rank == 14)
            card = "Ace of ";
        else if (rank == 13)
            card = "King of ";
        else if (rank == 12)
            card = "Queen of ";
        else if (rank == 11)
            card = "Jack of ";
        else
            card = Integer.toString(rank) + " of ";
        if (suit == 1)
            card += "Clubs";
        else if (suit == 2)
            card += "Diamonds";
        else if (suit == 3)
            card += "Hearts";
        else
            card += "Spades";
        return card;
    }//end toString
}//end Card class
