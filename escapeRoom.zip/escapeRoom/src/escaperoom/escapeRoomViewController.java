
package escaperoom;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.ActionEvent;
import javafx.event.EventHandler;
import javafx.fxml.*;
import javafx.scene.*;
import javafx.scene.control.*;
import javafx.scene.image.*;
import javafx.scene.layout.*;


/**
 *
 * @author Connor McCloskey
 */
public class escapeRoomViewController implements Initializable {    

//----------------------Fields-------------------------    
    
    //BorderPane for setting up the background image
    @FXML
    private BorderPane borderpane;
    
    //Labels
    @FXML
    private Label centerLabel, leftLabel, rightLabel;
    
    //Buttons
    @FXML
    private Button gambitButton, escapeButton, deadmanButton;
    
    //Booleans to track play progress
    private Boolean gambitWon = false, deadmanWon = false;
    
//----------------------Initialize------------------------- 
    
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        //popup for the story
        popup("welcome");
        
        //Set background image
        Image image = new Image("/escaperoom/images/background.png");
        BackgroundSize size = new BackgroundSize(1000, 800, true, true, true, false);
        BackgroundImage church = new BackgroundImage(image, BackgroundRepeat.REPEAT, BackgroundRepeat.NO_REPEAT, BackgroundPosition.CENTER, size);
        Background background = new Background(church);
        borderpane.setBackground(background);
        
        //Set label style to make it stand out from background
        leftLabel.setStyle("-fx-background-color: white;");
        centerLabel.setStyle("-fx-background-color: white;");
        rightLabel.setStyle("-fx-background-color: white;");
        
        //Set label text based on booleans
        setLabels();
        
        //Set Button text
        gambitButton.setText("Saint's Gambit");
        escapeButton.setText("Escape!");
        deadmanButton.setText("Dead Man's Hand");
        
        //Set Button onAction
        gambitButton.setOnAction(new SaintsGambit());
        deadmanButton.setOnAction(new DeadMansHand());
        escapeButton.setOnAction(new Escape());
        
        //enable escapeButton based on booleans
        if (gambitWon == true && deadmanWon == true){
            escapeButton.setDisable(false);
        }
        else{
            escapeButton.setDisable(true);
        } 
    }//end initialize

    //Method to handle setting the labels to correct text
    public void setLabels(){
        //left label
        if (gambitWon == true){
            leftLabel.setText("Status: Conquered!");
        }
        else{
            leftLabel.setText("Status: Unconquered!");
        }
        
        //Center Label
        if(gambitWon == true && deadmanWon == true){
            centerLabel.setText("Status: Unlocked!");
        }
        else{
            centerLabel.setText("Status: Locked!");
        }
        
        //Right label
        if(deadmanWon == true){
            rightLabel.setText("Status: Conquered!");
        }
        else{
            rightLabel.setText("Status: Unconquered!");
        }
    }
    
//----------------------Private class - Play Saint's Gambit------------------------- 
//Handle for gambitButton, set new scene on the stage (SuDoKu)
    private class SaintsGambit implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent event) {
            SuDokuViewController saint = new SuDokuViewController();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("SuDokuView.fxml"));
            fxmlLoader.setController(saint);
            try{
                fxmlLoader.load();
            }
            catch(IOException ex){
                throw new RuntimeException(ex);
            }
            Parent root = fxmlLoader.getRoot();
            Scene scene = new Scene(root);
            EscapeRoom.mainStage.setScene(scene);
            EscapeRoom.mainStage.show();
        }//end handle    
    }//end saintsGambit
    
//----------------------Private class - Play Dead Man's Hand-------------------------
//Handle for deadmanButton, set new scene on the stage (poker)
    private class DeadMansHand implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent event) {
            PokerViewControllerController deadman = new PokerViewControllerController();
            FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("PokerViewController.fxml"));
            fxmlLoader.setController(deadman);
            try{
                fxmlLoader.load();
            }
            catch(IOException ex){
                throw new RuntimeException(ex);
            }
            Parent root = fxmlLoader.getRoot();
            Scene scene = new Scene(root);
            EscapeRoom.mainStage.setScene(scene);
            EscapeRoom.mainStage.show();
        }//end handle
    }//end deadMansHand

//----------------------Method - Escape-------------------------
//Handle for escapeButton, popup saying you've won!
    private class Escape implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent event) {
            popup("win");
        }
    
    }//end Escape

//----------------------Method - Set gambitWon-------------------------
    public void setGambitWon(boolean status){gambitWon = status;}//end setGambitWon

//----------------------Method - set deadmanWon-------------------------
    public void setDeadManWon(boolean status){deadmanWon = status;}//end setDeadManWon

    public void popup(String type){
        if (type.equals("welcome")){
            Alert welcome = new Alert(Alert.AlertType.INFORMATION);
            welcome.setContentText("Ah, vacation at last. This year, you take a trip to the Greek countryside, exploring the many exotic things it has to offer – wine, the sea, and its culture, in today’s case, one of the many abandoned Orthodox churches.\n\n" +
"After stepping inside, the door behind you slams shut and locks. On either side, two busts – one of a woman, the other of a demonic skeleton, slowly turn to you, dust shaking from their ancient forms.\n\n" +
"“Welcome to the Basilica of the Numinous Puzzles,” the woman says. “Speak with me, and we shall play some Saint’s Gamble.”\n\n" +
"“Play with me,” the croaking voice of the skeleton says, “and we’ll run a few rounds of Dead Man’s Hand.”\n\n" +
"“If you wish to escape, you must beat us both,” the woman says. “Otherwise, you must join us here…forever.”\n\n" +
"The choice is yours. Speak with each bust to begin their challenges!");
            welcome.setTitle("The Basilica of the Numinous Puzzles");
            Optional<ButtonType> result = welcome.showAndWait();
        }//end if
        else if (type.equals("win")){
            Alert win = new Alert(Alert.AlertType.CONFIRMATION);
            win.setContentText("With a groan, the doors swing open. Congratulations, travelers!\n\nYou've escaped the Basicila of the Numinous Puzzles!");
            win.setTitle("You've Escaped!");
            Optional<ButtonType> result = win.showAndWait();
        }//end else if
        
    }
    
}//end escapeRoomViewController
