
package escaperoom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Iterator;

/**
 *
 * @author Connor McCloskey
 */

public class PokerHand {
    
    /*
    This class is used to represent a player's hand.
    
    It will contain a collection of Cards objects.
    
    It will also contain a method to determine what kind of hand you have,
    store that as a String, and also score your hand accordingly as an int.
    */
    
//----------------------Fields----------------------------------------
    private ArrayList<Card> hand = new ArrayList<Card>();
    private String pokerHandType;
    private int scoreHand;
    private boolean check = false;
    
    /*
    So what I discovered over the course of this is that I needed a more effective
    way of determining tie breakers.
    So, to do so, I have two additional ArrayLists:
    
    handTypeScored - stores the kind of hand you've scored.
    So, if you've got a four of a kind, the cards that make up the four of a kind are stored here.
    
    handRemaining - stores the other cards not part of your special hand
    So, in the example of four of a kind, this would score your one extra card
    This makes it far more effective to determine ties.
    */
    private ArrayList<Card> handTypeScored = new ArrayList<Card>();
    private ArrayList<Card> handRemaining = new ArrayList<Card>();
    
//----------------------Constructors----------------------------------------
    PokerHand(){
        pokerHandType = "empty";
        scoreHand = 0;
    }
    
    PokerHand(ArrayList<Card> handIn, String handTypeIn, int scoreIn){
        hand = handIn;
        pokerHandType = handTypeIn;
        scoreHand = scoreIn;
    }
    
    
//----------------------Getters----------------------------------------
    public ArrayList<Card> getHand (){return hand;}
    
    public String getHandType(){return pokerHandType;}
    
    public int getScore(){return scoreHand;}
    
    public ArrayList<Card> getRemaining(){return handRemaining;}
    
    
//----------------------Setters----------------------------------------
    public void addToHand(Card cardIn){
        if (hand.size() < 5)
            hand.add(cardIn);
        else
            System.out.println("Error in PokerHand - hand already has 5 cards!");
    }
    
    public void setHandType(String handTypeIn){
        pokerHandType = handTypeIn;
    }
    
    public void setScore(int scoreIn){
        scoreHand = scoreIn;
    }
    
    
//----------------------Other----------------------------------------
    public void clearHand(){
        hand.clear();
        handTypeScored.clear();
        handRemaining.clear();
    }
    
    public void checkHand(){
        Collections.sort(hand);
        if (royalFlush() == true){
            this.setScore(1000);
            this.setHandType("Royal Flush");
        }
        else if (straightFlush()== true){
            this.setScore(900 + hand.get(4).getRank());
            this.setHandType("Straight Flush");
        }
        else if (fourKind() == true){
            //For scoring, since we have a separate sorted ArrayList containing
            //the cards making up the four of a kind, we can just retrieve
            //the highest rank from that and add it to this.
            this.setScore(800 + handTypeScored.get(3).getRank());
            this.setHandType("Four of a Kind");
        }
        else if(fullHouse() == true){
            this.setScore(700 + hand.get(4).getRank());
            this.setHandType("Full House");
        }
        else if (flush() == true){
            this.setScore(600 + hand.get(4).getRank());
            this.setHandType("Flush");
        }
        else if (straight() == true){
            this.setScore(500 + hand.get(4).getRank());
            this.setHandType("Straight");
        }
        else if (threeKind() == true){
            //Same as four of a kind
            this.setScore(400 + handTypeScored.get(2).getRank());
            this.setHandType("Three of a Kind");
        }
        else if (twoPair() == true){
            //Same scoring mechanic as four of a kind
            this.setScore(300 + handTypeScored.get(3).getRank());
            this.setHandType("Two Pair");
        }
        else if (onePair() == true){
            //Same scoring mechanic as four of a kind
            this.setScore(100+hand.get(1).getRank());
            this.setHandType("One Pair");
        }
        else{
            this.setScore(50+hand.get(4).getRank());
            this.setHandType("High Card");
        }
        //For determining tie breakers, we now need to sort our handRemaining ArrayList
        Collections.sort(handRemaining);
    }//end check hand
    
    /*
    Here's the logic for this method:
    If we have a royal flush, then we know in our sorted ArrayList that the 5th card
    (index 4) should be an Ace, with descending order of cards from there, and that all
    cards must have the same suit. So, we just step through the ArrayList manually 
    to make sure that this is the case.
    */
    public boolean royalFlush(){
        if (hand.get(4).getRank() == 14){
            if (hand.get(3).getRank() == 13 && hand.get(3).getSuit() == hand.get(4).getSuit()){
                if (hand.get(2).getRank() == 12 && hand.get(2).getSuit() == hand.get(4).getSuit()){
                    if (hand.get(1).getRank() == 11 && hand.get(1).getSuit() == hand.get(4).getSuit()){
                        if (hand.get(0).getRank() == 10 && hand.get(0).getSuit() == hand.get(4).getSuit()){
                            check = true;
                        }
                    }
                }
            }       
        }//end overall if
        return check;
    }// end royalFlush()
    
    /*
    The logic to this is very similar as above. 
    */
    public boolean straightFlush(){
        for (int i = 0; i < hand.size()-1; i++){
            if (hand.get(i).getRank() == (hand.get(i+1).getRank()+1)){
                if (hand.get(i).getSuit() == hand.get(i+1).getSuit()){
                    check = true;
                }
                else
                    check = false;
            }
            else
                check = false;
        }//for loop
        return check;
    }//end straight flush
    
    /*
    Okay, so here's what this will do to check for four of a kind:
    First, we loop through the array based on rank
    If any card has another rank as another, we increment count, and add the card to handTypeScored
    If count equals 4, then we know we have four of a kind!
    If count never reaches for, then we know we can return false.
    Now, once we hit count = 4, we need to set check to true,
    and make our handRemaining equal to hand - handTypeScored.
    */
    public boolean fourKind(){
        for (int i = 0; i < hand.size()-1; i++){
            int count = 0;
            if (hand.get(i).getRank() == hand.get(i+1).getRank()){
                    count++;
                    handTypeScored.add(hand.get(i));
                    if (count == 4){
                        check = true;
                        handRemaining = hand;
                        Iterator<Card> it = handRemaining.iterator();
                        while (it.hasNext()){
                            if(handTypeScored.contains(it.next())){
                                it.remove();
                            }
                        }
                    }
                }
            }
        Collections.sort(handTypeScored);
        return check;
        } // end fourKind()        
    
    public boolean fullHouse(){
        if (threeKind() == true){
            if (onePair(handRemaining) == true){
                check = true;
            }
        }
        return check;
    }
    
    public boolean flush(){
        for (int i = 0; i < hand.size()-1; i++){
            if (hand.get(i).getSuit() == (hand.get(i+1).getSuit())){
                check = true;
            }
            else
                check = false;
        }
        return check;
    }
    
    public boolean straight(){
        for (int i = 0; i < (hand.size()-1); i++){
            if (hand.get(i).getRank() == ((hand.get(i+1).getRank())+1)){
                check = true;
            }
            else
                check = false;
        }
        return check;
    }
    
    public boolean threeKind(){
        handTypeScored.clear();
        for (int i = 0; i < hand.size()-1; i++){
            int count = 0;
            if (hand.get(i).getRank() == hand.get(i+1).getRank()){
                    count++;
                    handTypeScored.add(hand.get(i));
                    if (count == 3){
                        check = true;
                        handRemaining = hand;
                        Iterator<Card> it = handRemaining.iterator();
                        while (it.hasNext()){
                            if(handTypeScored.contains(it.next())){
                                it.remove();
                            }
                        }
                    }
                }
            }
        Collections.sort(handTypeScored);
        return check;
    }
    
    public boolean twoPair(){
        handTypeScored.clear();
        int count = 0;
        for (int i = 0; i < hand.size()-1; i++){
            for(int j = i+1; j < hand.size(); j++){
                if (hand.get(i).getRank() == hand.get(j).getRank()){
                    count++;
                    handTypeScored.add(hand.get(i));
                    handTypeScored.add(hand.get(j));
                    if (count == 2){
                        check = true;
                        handRemaining = hand;
                        Iterator<Card> it = handRemaining.iterator();
                        while (it.hasNext()){
                            if(handTypeScored.contains(it.next())){
                                it.remove();
                            }
                        }
                    }//end if statement
                }//end if statement
            }//end inner loop
        }//end outer loop
        
        
        return check;
    }
    
    public boolean onePair(){
        handTypeScored.clear();
        for (int i = 0; i < hand.size()-1; i++){
            for(int j = i+1; j < hand.size(); j++){
                if (hand.get(i).getRank() == hand.get(j).getRank()){
                    handTypeScored.add(hand.get(i));
                    handTypeScored.add(hand.get(j));
                    check = true;
                    handRemaining = hand;
                    Iterator<Card> it = handRemaining.iterator();
                    while (it.hasNext()){
                        if(handTypeScored.contains(it.next())){
                            it.remove();
                        }
                    }
                }//end if statement
            }//end inner loop
        }//end outer loop
        Collections.sort(handTypeScored);
        return check;
    }
    
        public boolean onePair(ArrayList<Card> handLeft){
        handTypeScored.clear();
        for (int i = 0; i < handLeft.size()-1; i++){
            for(int j = i+1; j < handLeft.size(); j++){
                if (handLeft.get(i).getRank() == handLeft.get(j).getRank()){
                    handTypeScored.add(handLeft.get(i));
                    handTypeScored.add(handLeft.get(j));
                    check = true;
                    handRemaining = handLeft;
                    Iterator<Card> it = handRemaining.iterator();
                    while (it.hasNext()){
                        if(handTypeScored.contains(it.next())){
                            it.remove();
                        }
                    }
                }//end if statement
            }//end inner loop
        }//end outer loop
        Collections.sort(handTypeScored);
        return check;
    }
}// end poker hands class