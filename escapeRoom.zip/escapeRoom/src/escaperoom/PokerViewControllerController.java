
package escaperoom;

import java.io.IOException;
import java.net.URL;
import java.util.Optional;
import java.util.ResourceBundle;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.FXMLLoader;
import javafx.fxml.Initializable;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.control.*; //changed to import all controls needed
import javafx.scene.image.*;

/**
 *
 * @author Connor McCloskey
 */
public class PokerViewControllerController implements Initializable {
    
    /*
    This class will also need to:
    1 - Track the player's score
    2 - Track the number of rounds/games played
    3 - End the game & reveal lock code once the player has 50 points
    3b - End the game once the player reaches 1000 games
    */
    
    //----------------------Fields----------------------------------------
    @FXML
    private ImageView imageComputerOne, imageComputerTwo, imageComputerThree, imageComputerFour,imageComputerFive;
    @FXML
    private ImageView imagePlayerOne, imagePlayerTwo, imagePlayerThree, imagePlayerFour, imagePlayerFive;
    @FXML
    private Label labelPlayerHand, labelComputerHand, winnerLabel, scoreLabel;
    @FXML
    private Button newGameButton, betButton, foldButton;
    
    private int gameNumber = 0;
    private int playerScore = 0;
    
    private PokerGames game = new PokerGames();
    
    private Image defaultImage;
    private Image playerImageOne, playerImageTwo, playerImageThree, playerImageFour, playerImageFive;
    private Image compImageOne, compImageTwo, compImageThree, compImageFour, compImageFive;
    
    
    //----------------------Initialize----------------------------------------
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        //First up, set up our card pictures
        //We create a default image, and assign it to each ImageView in our UI
        //Then we adjust its height and width to fit a bit better in the new window
        defaultImage = new Image("/escaperoom/images/rrcc_card.png");
        setDefaultImages();
        
        //Now, we'll set up our labels and buttons
        //Set their text and OnAction methods
        newGameButton.setText("New Game");
        newGameButton.setOnAction(new NewGameButtonListener());
        
        betButton.setText("Bet");
        betButton.setOnAction(new BetButtonListener());
        
        foldButton.setText("Fold");
        foldButton.setOnAction(new FoldButtonListener());
        
        setLabelDefaults();
        scoreLabel.setText(playerScore + " points");

        //Now, let's start the game!
        //Instantiate new PokerGames
        //read in the file of hands
        //populate the hands
        game.readFile();
        game.populateHands(gameNumber);
       
        //Now that we have that, let's set the player's hand
        setPlayerHandImages();
        
        //And don't forget to inform the player how to play!
        popup("welcome");
    }//end public void initialize
    
    
    //----------------------Methods----------------------------------------
    public void setDefaultImages(){
        //code for setting images back to default and setting their initial width/height
        imageComputerOne.setImage(defaultImage);
        imageComputerOne.setFitHeight(80);
        imageComputerOne.setFitWidth(80);
        
        imageComputerTwo.setImage(defaultImage);
        imageComputerTwo.setFitHeight(80);
        imageComputerTwo.setFitWidth(80);
        
        imageComputerThree.setImage(defaultImage);
        imageComputerThree.setFitHeight(80);
        imageComputerThree.setFitWidth(80);
        
        imageComputerFour.setImage(defaultImage);
        imageComputerFour.setFitHeight(80);
        imageComputerFour.setFitWidth(80);
        
        imageComputerFive.setImage(defaultImage);
        imageComputerFive.setFitHeight(80);
        imageComputerFive.setFitWidth(80);
        
        //Next - same as before, we'll set up the player's hand
        imagePlayerOne.setImage(defaultImage);
        imagePlayerOne.setFitHeight(80);
        imagePlayerOne.setFitWidth(80);
        
        imagePlayerTwo.setImage(defaultImage);
        imagePlayerTwo.setFitHeight(80);
        imagePlayerTwo.setFitWidth(80);
        
        imagePlayerThree.setImage(defaultImage);
        imagePlayerThree.setFitHeight(80);
        imagePlayerThree.setFitWidth(80);
        
        imagePlayerFour.setImage(defaultImage);
        imagePlayerFour.setFitHeight(80);
        imagePlayerFour.setFitWidth(80);
        
        imagePlayerFive.setImage(defaultImage);
        imagePlayerFive.setFitHeight(80);
        imagePlayerFive.setFitWidth(80);
    }//end setDefaultImages
    
    public void setPlayerHandImages(){

        //You know, my name convention for these images was crap, but it works!
        
        //First, retrieve the right images
        playerImageOne = new Image(game.getPlayer().getHand().get(0).getImageFile());
        playerImageTwo = new Image(game.getPlayer().getHand().get(1).getImageFile());
        playerImageThree = new Image(game.getPlayer().getHand().get(2).getImageFile());
        playerImageFour = new Image(game.getPlayer().getHand().get(3).getImageFile());
        playerImageFive = new Image(game.getPlayer().getHand().get(4).getImageFile());
        
        //Next, send those images to the relevant ImageViews
        imagePlayerOne.setImage(playerImageOne);
        imagePlayerTwo.setImage(playerImageTwo);
        imagePlayerThree.setImage(playerImageThree);
        imagePlayerFour.setImage(playerImageFour);
        imagePlayerFive.setImage(playerImageFive);
    }//end setPlayerHandImages
    
    public void setComputerHandImages(){
        //First, retrive the right images
        compImageOne = new Image(game.getComputer().getHand().get(0).getImageFile());
        compImageTwo = new Image(game.getComputer().getHand().get(1).getImageFile());
        compImageThree = new Image(game.getComputer().getHand().get(2).getImageFile());
        compImageFour = new Image(game.getComputer().getHand().get(3).getImageFile());
        compImageFive = new Image(game.getComputer().getHand().get(4).getImageFile());
        
        //Next, send those images to the relevant ImageViews
        imageComputerOne.setImage(compImageOne);
        imageComputerTwo.setImage(compImageTwo);
        imageComputerThree.setImage(compImageThree);
        imageComputerFour.setImage(compImageFour);
        imageComputerFive.setImage(compImageFive);
    }//end setComputerHandImages
    
    public void setComputerDefaultImages(){
        imageComputerOne.setImage(defaultImage);
        imageComputerTwo.setImage(defaultImage);
        imageComputerThree.setImage(defaultImage);
        imageComputerFour.setImage(defaultImage);
        imageComputerFive.setImage(defaultImage);
    }//end setComputerDefaultImages
    
    public void setLabelDefaults(){
        labelPlayerHand.setText("Your Hand");
        labelComputerHand.setText("Opponent Hand");
        winnerLabel.setText("Who Will Win?");
    }//end setLabelDefaults
    
    public void popup(String type){
        if (type.equals("welcome")){
            Alert welcome = new Alert(Alert.AlertType.INFORMATION);
            welcome.setContentText("Let's Play Some Poker! Score 50 points to win! To play a new round, select New Game.");
            welcome.setTitle("Welcome to Poker");
            Optional<ButtonType> result = welcome.showAndWait();
        }//end if
        else if (type.equals("win")){
            Alert win = new Alert(Alert.AlertType.CONFIRMATION);
            win.setContentText("Congraulations! You Win!");
            win.setTitle("You Win!");
            Optional<ButtonType> result = win.showAndWait();
            hubReturn();
        }//end else if
        
    }
//----------------------Method - Hub Return------------------------- 
//if the player has won, send them back to the Escape Room hub, and change
//the status of appropriate variables (gambitWon and leftLabel)
    public void hubReturn(){
    escapeRoomViewController hub = new escapeRoomViewController();
    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("escapeRoomView.fxml"));
    fxmlLoader.setController(hub);
    try{
        fxmlLoader.load();
    }
    catch(IOException ex){
        throw new RuntimeException(ex);
    }
    Parent root = fxmlLoader.getRoot();
    hub.setDeadManWon(true);
    Scene scene = new Scene(root, 1000, 800);
    EscapeRoom.mainStage.setScene(scene);
    EscapeRoom.mainStage.show();
}//end hubReturn 
    
//----------------------EventHandler classes----------------------------------------
    private class BetButtonListener implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent event) {
            //Check player's hand and set the appropriate label
            game.getPlayer().checkHand();
            labelPlayerHand.setText(game.getPlayer().getHandType());
            
            //Check computer's hand and set the appropriate label
            game.getComputer().checkHand();
            labelComputerHand.setText(game.getComputer().getHandType());
            
            //Set the computer hand images now that it can be revealed
            setComputerHandImages();
            
            //Game logic
            //If the player's hand is better, they win and gain 10 points
            //Else, they lose and lose 10 points
            //If the player's score is 50 or over, they have officially one
            boolean win = game.compareHands();
            
            if (win == true){
                winnerLabel.setText("You win the hand!");
                playerScore += 10;
                scoreLabel.setText(playerScore + " points");
                if (playerScore >= 50){
                    popup("win");
                }
            }
            else{
                winnerLabel.setText("You lost the hand!");
                playerScore -= 10;
                if (playerScore < 0){
                    playerScore = 0;
                }
            }
        }
    }//end BetButtonListener
    
    private class FoldButtonListener implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent event) {
            //Check player's hand and set the appropriate label
            game.getPlayer().checkHand();
            labelPlayerHand.setText(game.getPlayer().getHandType());
            
            //Check computer's hand and set the appropriate label
            game.getComputer().checkHand();
            labelComputerHand.setText(game.getComputer().getHandType());
            
            //Set the computer hand images now that it can be revealed
            setComputerHandImages();
        }
    }//end FoldButton Listener
    
    private class NewGameButtonListener implements EventHandler<ActionEvent>{
        @Override
        public void handle(ActionEvent event) {
            //Check to see if gameNumber == 999
            //if it is, set gameNumber back to zero
            if (gameNumber == 999){
                gameNumber = 0;
            }
            else{
                gameNumber++;
            }
            game.populateHands(gameNumber);
            setComputerDefaultImages();
            setPlayerHandImages();
            setLabelDefaults();
        }
    }//end NewGameListener
}//end controller class
