
package escaperoom;
import java.io.*;

/**
 *
 * @author Connor McCloskey
 */
public class PokerGames {
    
//----------------------Fields----------------------------------------
    //Variables for IO stream
    private File file;
    private FileReader fileReader;
    private BufferedReader bufferedReader;
    private String in;
    
    //Computer's hand
    private PokerHand computer = new PokerHand();
    //Player's hand
    private PokerHand player = new PokerHand();
    
    //1D String array to hold in lines from the file
    private String[] allGames = new String[1001];
  
//----------------------Constructors----------------------------------------
    PokerGames(){file = new File("p054_poker.txt");}
    
//----------------------Getters----------------------------------------
    public PokerHand getComputer(){return computer;}
    
    public PokerHand getPlayer(){return player;}
    
    public String[] getAllGames(){return allGames;}
    
//----------------------Other----------------------------------------
    public void readFile(){
        try{
            fileReader = new FileReader(file); //throw FileNoutFoundException
            bufferedReader = new BufferedReader(fileReader);
            //System.out.println("Checkpoint - readFile, prior to while loop - in: " + in);
            int i = 0;
            while ((in = bufferedReader.readLine()) != null){
                //System.out.println("Checkpoint - readFile - i: " + i);
                //System.out.println("Checkpoint - readFile - in: " + in);
                in = in.replaceAll("\\s+","");
                allGames[i] = in;
                //System.out.println("Checkpoint - readFile - allGames[i]: " + allGames[i]);
                i++;
                }//end while
            fileReader.close();
        }//end try
        catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
            System.out.println("File not found, PokerGames");
        }//end FileNotFound catch
        catch (IOException ex){
            System.out.println(ex.getMessage());
            System.out.println("IOExcepiton, PokerGames");
        }//end IOException catch        
    }//end read file
    
    public void populateHands(int gameNumber){
        player.clearHand();
        int rankIn, suitIn = 0;
        char rank, suit;
        String playerString = allGames[gameNumber].substring(0,10);
        //Loop through playerString substring to create cards
        //Below - originally i+=2
        for (int i = 0; i < playerString.length(); i+=2){
            //could be 2 - 9 OR T/J/K/Q/A
            rank = playerString.charAt(i);
            //System.out.println("Checkpoint - populateHands - rank: " + rank);
            switch(rank){
                case 'T':
                    rankIn = 10;
                    break;
                case 'J':
                    rankIn = 11;
                    break;
                case 'Q':
                    rankIn = 12;
                    break;
                case 'K':
                    rankIn = 13;
                    break;
                case 'A':
                    rankIn = 14;
                    break;
                default:
                    rankIn = Character.getNumericValue(rank);
                }
            suit = playerString.charAt(i+1);
            //System.out.println("Checkpoint - populateHands - suit: " + suit);
            switch(suit){
                case 'C':
                    suitIn = 1;
                    break;
                case 'D':
                    suitIn = 2;
                    break;
                case 'H':
                    suitIn = 3;
                    break;
                case 'S':
                    suitIn = 4;
                    break;
                }
                Card in = new Card(rankIn, suitIn);
                player.addToHand(in);
            }//end player for loop
        
        computer.clearHand();
        String computerString = allGames[gameNumber].substring(10);
        for (int i = 0; i < computerString.length(); i+=2){
            //could be 2 - 9 OR T/J/K/Q/A
            rank = computerString.charAt(i);
            switch(rank){
                case 'T':
                    rankIn = 10;
                    break;
                case 'J':
                    rankIn = 11;
                    break;
                case 'Q':
                    rankIn = 12;
                    break;
                case 'K':
                    rankIn = 13;
                    break;
                case 'A':
                    rankIn = 14;
                    break;
                default:
                    rankIn = Character.getNumericValue(rank);
                }
            suit = computerString.charAt(i+1);
            switch(suit){
                case 'C':
                    suitIn = 1;
                    break;
                case 'D':
                    suitIn = 2;
                    break;
                case 'H':
                    suitIn = 3;
                    break;
                case 'S':
                    suitIn = 4;
                    break;
                }
                Card in = new Card(rankIn, suitIn);
                computer.addToHand(in);
            }//end player for loop
    }//end populateHands method
    
    public boolean compareHands(){
        if (player.getScore() > computer.getScore()){
            return true;
        }
        else if (player.getScore() == computer.getScore()){
            int playerTie = player.getRemaining().size()-1;
            int computerTie = computer.getRemaining().size()-1;
            if (playerTie > computerTie){
                return true;
            }
            else{
                return false;
            }
        }
        else{
            return false;
        }
    }//end compareHands
}//end poker games class