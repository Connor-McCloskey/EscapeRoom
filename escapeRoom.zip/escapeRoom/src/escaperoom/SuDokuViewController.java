package escaperoom;

import java.net.URL;
import java.util.ResourceBundle;
import javafx.event.*;
import javafx.fxml.FXML;
import javafx.fxml.Initializable;
import javafx.scene.control.*;
import java.io.*;
import java.util.*;
import javafx.fxml.FXMLLoader;
import javafx.scene.Parent;
import javafx.scene.Scene;
import javafx.scene.layout.GridPane;

public class SuDokuViewController implements Initializable, EventHandler<ActionEvent> {
    
    /*///////// Variables \\\\\\\\\*/
    @FXML
    private Label titleLabel;
    @FXML
    private GridPane grid;
    @FXML
    private Button submitButton;
    TextField [][] cells = new TextField[9][9];
    
    private List<Integer> check = new ArrayList<Integer>();
    
    private String gridWanted = null;
    
    private File file;
    private FileReader fileReader;
    private BufferedReader bufferedReader;
    private String in;

    /*///////// Methods \\\\\\\\\*/
    @Override
    public void initialize(URL url, ResourceBundle rb) {
        
        //Set text for the title and submit button
        titleLabel.setText("Su Doku!");
        titleLabel.setStyle( "-fx-font-family: Arial;" 
                + "-fx-font-size: 24px;");
        submitButton.setText("Check Answer");
        submitButton.setStyle( "-fx-font-family: Arial;" 
                + "-fx-font-size: 12px;");


        /*Instantiation of our 2D array of text fields
        On each index, instantiate a new text field
        Then set the style of the new text field
        Then add our new text field at the correct grid pane location
        */
        for(int row = 0; row < 9; row++){
            for(int col = 0; col < 9; col++){
                cells[row][col] = new TextField();
                cells[row][col].setStyle( "-fx-font-family: Arial;" 
                + "-fx-font-size: 18px;");
                grid.add(cells[row][col], col, row);
            }
        }//end of for loop - instantiate textfields
        
        //Now, we'll get the random board we want to use
        Random rand = new Random();
        int boardWanted = rand.nextInt(50);
        String boardNumber = "";
        if(boardWanted < 10){
            boardNumber = "0" + String.valueOf(boardWanted+1);
        }
        else{
            boardNumber = String.valueOf(boardWanted+1);
        }
        String gridWanted = "Grid " + boardNumber;
        
        //Open our file
        //Then loop through and enter information into our cells
        try{
        //First, open the file, and give it to bufferedReader to work with
        file = new File("p096_sudoku.txt");
        fileReader = new FileReader(file); //throw FileNoutFoundException
        bufferedReader = new BufferedReader(fileReader);

        //read through file, so long as the string we're inputting into doesn't point to null
        while ((in = bufferedReader.readLine()) != null){
                //If the string equals the title of the grid we want, start importing
                //If it doesn't, we continue to loop until it does
                if (in.equals(gridWanted)){
                    //We know that there are a set number of lines we need to import and assign to our cells
                    //10 in total, which includes the title of the grid
                    //We've already read the first (the title), so set linesRead equal to 1
                    int linesRead = 1;
                    
                    //We'll use a while loop to count the number of lines we've read
                    while(linesRead < 10){
                        //Now, we begin looping through the cell array and setting 
                        for (int row = 0; row < 9; row++){
                            //get the next lines
                            in = bufferedReader.readLine();
                            //since we've read another line, increment linesRead
                            linesRead++;
                            for (int col = 0; col < 9; col++){
                                String character = String.valueOf(in.charAt(col));
                                //Since 0s represent blank space, set the text in cells[row][col] to blank
                                if(character.equals("0")){
                                    cells[row][col].setText("");
                                }
                                //Otherwise, set the text accordingly
                                else{
                                    cells[row][col].setText(character);
                                }
                            }//end col loop
                        }//end row loop
                    }//end while loop
                    //Now, we can close the file and break out of the while loop
                    fileReader.close();
                    break;
                }
        }//end while loop
        if(bufferedReader != null){
                bufferedReader.close();
        }// end if
        else{
                System.out.println("No need to close, file not opened.");
            }
        }//end of try
        //catching error message from for the file opening try
        catch(FileNotFoundException ex){
            System.out.println(ex.getMessage());
            System.out.println("File not found");
        }
        catch (IOException ex){
            System.out.println(ex.getMessage());
            System.out.println("readLine() method");
        }//end of catch
        
        //to send action event to handle method
        submitButton.setOnAction(this); 
        
    }//End of initialize method

    @Override
    public void handle(ActionEvent event){
        //Once our button is clicked, we need to check if the player's answers are right
        
        /*First, let's check the player's answers in rows*/
        try{
        for(int row = 0; row < 9; row++){
            //Clear check list to prevent errors from previous row
            check.clear();
            for(int col = 0; col < 9; col++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   //System.out.println("Checkpoint 2");
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check row for loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        //Now, let's check the player's answers in columns
        try{
        for (int col = 0; col < 9; col++){
            //Clear our check list to prevent errors from previous column
            check.clear();
            for(int row = 0; row<9; row++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }//end try
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check col for loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        //Finally, let's check the player's squares
        //Since we just have one big 2D array, these need to be hard-coded in
        //However, the checking method is the same as the above
        
        //Square 1
        try{
        for (int row = 0; row < 2; row++){
            //Clear our check list to prevent errors from previous entries
            check.clear();
            for(int col = 0; col<2; col++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }//end try
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check square loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        //Square 2
        try{
        for (int row = 0; row < 2; row++){
            //Clear our check list to prevent errors from previous entries
            check.clear();
            for(int col = 3; col< 5; col++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }//end try
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check square loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        //Square 3
        try{
        for (int row = 0; row < 2; row++){
            //Clear our check list to prevent errors from previous entries
            check.clear();
            for(int col = 6; col< 8; col++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }//end try
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check square loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        //Square 4
        try{
        for (int row = 3; row < 5; row++){
            //Clear our check list to prevent errors from previous entries
            check.clear();
            for(int col = 0; col< 2; col++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }//end try
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check square loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        //Square 5
        try{
        for (int row = 3; row < 5; row++){
            //Clear our check list to prevent errors from previous entries
            check.clear();
            for(int col = 3; col< 5; col++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }//end try
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check square loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        //Square 6
        try{
        for (int row = 3; row < 5; row++){
            //Clear our check list to prevent errors from previous entries
            check.clear();
            for(int col = 6; col< 8; col++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }//end try
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check square loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        //Square 7
        try{
        for (int row = 6; row < 8; row++){
            //Clear our check list to prevent errors from previous entries
            check.clear();
            for(int col = 0; col< 2; col++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }//end try
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check square loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        //Square 8
        try{
        for (int row = 6; row < 8; row++){
            //Clear our check list to prevent errors from previous entries
            check.clear();
            for(int col = 3; col< 5; col++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }//end try
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check square loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        //Square 9
        try{
        for (int row = 6; row < 8; row++){
            //Clear our check list to prevent errors from previous entries
            check.clear();
            for(int col = 6; col < 8; col++){
                Integer x = null;
                //Try to import the player's answer
                //If it's anything other than an int, throw an exception - NumberFormatException
                try{
                    x = Integer.parseInt(cells[row][col].getText());
                }//end try
                catch(NumberFormatException ex){
                    popup("invalid");
                    return;
                }
               if(check.contains(x) == true)
               {
                    throw new InputMismatchException();
               }//end if
               else{
                   check.add(x);
               }//end else
            }//end inner for loop
        }//end check square loop
        }//end try
        catch(InputMismatchException ex){
            popup("wrong");
            return;
        }
        
        popup("correct");
        
    }//End of handle method

    public void popup(String type){
        if (type.equals("correct")){
            Alert correct = new Alert(Alert.AlertType.CONFIRMATION);
            correct.setContentText("Congratulations! That's correct!");
            correct.setTitle("You Win!");
            Optional<ButtonType> result = correct.showAndWait();
            hubReturn();
        }//end if
        else if (type.equals("wrong")){
            Alert wrong = new Alert(Alert.AlertType.ERROR);
            wrong.setContentText("Sorry, that's not correct.");
            wrong.setTitle("Wrong Answer!");
            Optional<ButtonType> result = wrong.showAndWait();
        }//end else if
        else{
            Alert invalid = new Alert(Alert.AlertType.ERROR);
            invalid.setContentText("Invalid Answer.\nPlease use only whole integers for your answer.");
            invalid.setTitle("Invalid Answer");
            Optional<ButtonType>result = invalid.showAndWait();
        }//end else
    }//end of popup method

//----------------------Method - Hub Return------------------------- 
//if the player has won, send them back to the Escape Room hub, and change
//the status of appropriate variables (gambitWon and leftLabel)
public void hubReturn(){
    escapeRoomViewController hub = new escapeRoomViewController();
    FXMLLoader fxmlLoader = new FXMLLoader(getClass().getResource("escapeRoomView.fxml"));
    fxmlLoader.setController(hub);
    try{
        fxmlLoader.load();
    }
    catch(IOException ex){
        throw new RuntimeException(ex);
    }
    Parent root = fxmlLoader.getRoot();
    hub.setGambitWon(true);
    Scene scene = new Scene(root, 1000, 800);
    EscapeRoom.mainStage.setScene(scene);
    EscapeRoom.mainStage.show();
}//end hubReturn    
    
}//End of SoDokuViewController class
